// Netlify Function — secure proxy to Claude API
// Compatible with Netlify Functions 2.0

export default async (req) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json', ...cors }
    });
  }

  // Read API key (Netlify Functions 2.0 supports both)
  const apiKey = (typeof Netlify !== 'undefined' && Netlify.env)
    ? Netlify.env.get('ANTHROPIC_API_KEY')
    : process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return new Response(JSON.stringify({
      error: 'API key not configured',
      hint: 'Set ANTHROPIC_API_KEY in Netlify Site Settings → Environment variables → scope: Functions'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...cors }
    });
  }

  let body;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json', ...cors }
    });
  }

  const { prompt, max_tokens = 1500 } = body;
  if (!prompt || typeof prompt !== 'string') {
    return new Response(JSON.stringify({ error: 'Missing or invalid prompt' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json', ...cors }
    });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Claude API error:', response.status, data);
      return new Response(JSON.stringify({
        error: 'Upstream API error',
        status: response.status,
        details: data?.error?.message || 'Unknown error'
      }), {
        status: response.status,
        headers: { 'Content-Type': 'application/json', ...cors }
      });
    }

    const text = (data.content || [])
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('\n');

    return new Response(JSON.stringify({ text }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store',
        ...cors
      }
    });
  } catch (e) {
    console.error('Function error:', e);
    return new Response(JSON.stringify({
      error: 'Internal error',
      message: e.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...cors }
    });
  }
};
